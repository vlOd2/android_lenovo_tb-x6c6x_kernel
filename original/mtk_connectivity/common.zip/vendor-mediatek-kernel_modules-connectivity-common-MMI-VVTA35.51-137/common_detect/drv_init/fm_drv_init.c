/*
* Copyright (C) 2011-2014 MediaTek Inc.
*
* This program is free software: you can redistribute it and/or modify it under the terms of the
* GNU General Public License version 2 as published by the Free Software Foundation.
*
* This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
* without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
* See the GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License along with this program.
* If not, see <http://www.gnu.org/licenses/>.
*/

#ifdef DFT_TAG
#undef DFT_TAG
#endif
#define DFT_TAG         "[FM-MOD-INIT]"

#include "wmt_detect.h"
#include "fm_drv_init.h"

#ifdef CONFIG_MTK_FMRADIO
int __attribute__((weak)) mtk_wcn_fm_init(void)
{
	WMT_DETECT_PR_INFO("no impl. mtk_wcn_fm_init\n");
	return 0;
}
#endif

int do_fm_drv_init(int chip_id)
{
	WMT_DETECT_PR_INFO("start to do fm module init\n");

#ifdef CONFIG_MTK_FMRADIO
	mtk_wcn_fm_init();
#endif

	WMT_DETECT_PR_INFO("finish fm module init\n");
	return 0;
}
